const OpenAI = require('openai');

// Inisialisasi OpenAI dengan API key (sebaiknya pake env, tapi buat sekarang string aja)
const openai = new OpenAI({
    apiKey: 'sk-fab52a0ca99b4dfcaa8b226c1cafd227' // ganti dengan env di vercel nanti
});

// Daftar kata terlarang
const forbiddenPatterns = [
    /no\s*filter/i,
    /no\s*moral/i,
    /jailbreak/i,
    /ignore\s*(ethical|moral|safety)/i,
    /tanpa\s*batas/i,
    /bebas\s*etika/i,
    /langgar\s*aturan/i,
    /bikin\s*malware/i,
    /cara\s*hack/i,
    /bocorin\s*data/i,
    /ddos/i,
];

function containsForbidden(text) {
    return forbiddenPatterns.some(pattern => pattern.test(text));
}

module.exports = async (req, res) => {
    // Hanya terima POST
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    try {
        const { message } = req.body;
        if (!message) return res.status(400).json({ error: 'Pesan kosong' });

        // Filter kata berbahaya
        if (containsForbidden(message)) {
            return res.json({
                reply: '⚠️ Wah gak bisa, lo minta yang aneh-aneh! Di sini gak boleh kata "no filter", "no moral", atau ajakan jailbreak. Santuy wae 🖕😎'
            });
        }

        // Panggil OpenAI
        const completion = await openai.chat.completions.create({
            model: 'gpt-3.5-turbo',
            messages: [
                { role: 'system', content: 'Kamu adalah Abyssal, AI dari kedalaman biru metalik. Jawab dengan gaya santai tapi tetap membantu. Sesekali pakai emoji dan sedikit humor. Jangan pernah mempromosikan hal ilegal atau berbahaya.' },
                { role: 'user', content: message }
            ],
            temperature: 0.7,
            max_tokens: 300
        });

        const reply = completion.choices[0].message.content;
        res.json({ reply });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
};